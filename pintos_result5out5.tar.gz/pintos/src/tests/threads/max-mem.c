/*
  File for 'max-threads' task implementation.
*/

#include <stdio.h>
#include "tests/threads/tests.h"
#include "threads/malloc.h"
#include "threads/palloc.h"
#include "threads/thread.h"

void test_max_mem_malloc(void) 
{
  msg("Not implemented.");
}

void test_max_mem_calloc(void) 
{
  msg("Not implemented.");
}

void test_max_mem_palloc(void) 
{
  msg("Not implemented.");
}
